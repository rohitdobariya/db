package com.datatbasetrigger.service;

import com.datatbasetrigger.domain.Records;
import com.datatbasetrigger.repository.DatabaseTriggerRepository;
import com.datatbasetrigger.service.impl.ServiceImpl;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Arrays;
import java.util.List;

@RunWith(SpringRunner.class)
public class ServiceTest {

    @Autowired
    private Service service;

    @MockBean
    private DatabaseTriggerRepository databaseTriggerRepository;

    @Test
    public void findRecordByIsNew_test(){

        Mockito.when(databaseTriggerRepository.findRecordByIsNew(true)).thenReturn(Arrays.asList(new Records()));

        final List<Records> recordByIsNew = service.findRecordByIsNew(true);

        Assert.assertEquals(recordByIsNew.size(),1);
        Mockito.verify(databaseTriggerRepository,Mockito.times(1)).findRecordByIsNew(true);
    }

    @Test
    public void findAll_test(){

        Mockito.when(databaseTriggerRepository.findAll()).thenReturn(Arrays.asList(new Records()));

        final List<Records> findAll = service.findAll();

        Assert.assertEquals(findAll.size(),1);
        Mockito.verify(databaseTriggerRepository,Mockito.times(1)).findAll();
    }

    @Test
    public void save_test(){

        Records records = new Records();
        records.setName("test");

        Mockito.when(databaseTriggerRepository.save(Mockito.any(Records.class))).thenReturn(records);

        final Records save = service.save(records);

        Assert.assertNotNull(save);
        Assert.assertEquals(save.getName(),"test");
        Mockito.verify(databaseTriggerRepository,Mockito.times(1)).save(Mockito.any(Records.class));
    }

    @TestConfiguration
    static class ServiceImplTestContextConfiguration {

        @Bean
        public Service service() {
            return new ServiceImpl();
        }
    }

}
