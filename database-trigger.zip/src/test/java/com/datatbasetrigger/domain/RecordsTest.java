package com.datatbasetrigger.domain;

import org.junit.Assert;
import org.junit.Test;

public class RecordsTest {

    @Test
    public void records_test(){
        Records records = new Records();
        records.setId(1);
        records.setName("test");
        records.setNew(true);

        Assert.assertEquals(records.getId(), 1 );
        Assert.assertEquals(records.getName(), "test" );
        Assert.assertEquals(records.isNew(), true);
    }
}
