package com.datatbasetrigger;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.datatbasetrigger.repository.DatabaseTriggerRepository;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;


@RunWith(SpringRunner.class)
@SpringBootTest( classes = DatabaseTriggerApp.class)
@AutoConfigureMockMvc
public class DatabaseTriggerAppTest {
    @Autowired
    private MockMvc mvc;

    @Autowired
    private DatabaseTriggerRepository repository;


    @Test
    public void getRecord_test() throws Exception {
        mvc.perform(get("/api/get")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    @Test
    public void addRecord_test() throws Exception {
        mvc.perform(get("/api/add")
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }


}
