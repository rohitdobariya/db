INSERT INTO record (name,isnew) VALUES('ASIM1',1);
INSERT INTO record (name,isnew) VALUES('ASIM2',1);
INSERT INTO record (name,isnew) VALUES('ASIM3',1);