package com.datatbasetrigger.controller;

import java.util.ArrayList;
import java.util.List;

import com.datatbasetrigger.service.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.datatbasetrigger.domain.Records;
import com.datatbasetrigger.repository.DatabaseTriggerRepository;


@RestController
@RequestMapping("/api")
public class DatabaseTriggerController {

	@Autowired
	Service service;

	final String lexicon = "ABCDEFGHIJKLMNOPQRSTUVWXYZ12345674890";

	final java.util.Random rand = new java.util.Random();

	@GetMapping("/get")
	public ResponseEntity<List<Records>> getAllRecords() {
		List<Records> listNewRecords = service.findAll();
		return new ResponseEntity<List<Records>>(listNewRecords, HttpStatus.OK);
	}

	@GetMapping("/add")
	public ResponseEntity<List<Records>> addNewRecords() {

			List<Records> records = new ArrayList<Records>();
			for (int i = 0; i < 3; i++) {
				Records record = new Records();
				record.setName(getRandomName());
				record.setNew(true);
				records.add(record);
			}
			for (Records record : records) {
				record = service.save(record);
			}
			return new ResponseEntity<List<Records>>(records, HttpStatus.OK);
	}

	public String getRandomName() {
		StringBuilder builder = new StringBuilder();
		while(builder.toString().length() == 0) {
			int length = rand.nextInt(5)+5;
			for(int i = 0; i < length; i++) {
				builder.append(lexicon.charAt(rand.nextInt(lexicon.length())));
			}
		}
		return builder.toString();
	}
}
