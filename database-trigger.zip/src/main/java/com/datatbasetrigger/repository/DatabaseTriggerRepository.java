package com.datatbasetrigger.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.datatbasetrigger.domain.Records;

public interface DatabaseTriggerRepository extends JpaRepository<Records, Long> {
	List<Records> findRecordByIsNew(boolean isNew);
}

