package com.datatbasetrigger.service;

import com.datatbasetrigger.domain.Records;

import java.util.List;

public interface Service {
    List<Records> findRecordByIsNew(boolean isNew);
    List<Records> findAll();
    Records save(Records records);
}
