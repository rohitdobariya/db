package com.datatbasetrigger.service;

import com.datatbasetrigger.domain.Records;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

@Service
public class DatabaseTriggerService implements ApplicationRunner {

    private static final int TRIGGER_PERIOD = 10;

    @Autowired
    private com.datatbasetrigger.service.Service service;

    @Override
    public void run(ApplicationArguments applicationArguments) throws Exception {
        ScheduledExecutorService ses = Executors.newScheduledThreadPool(10);
        ses.scheduleAtFixedRate(new Runnable() {
            @Override
            public void run() {
                List<Records> listNewRecords = service.findRecordByIsNew(true);
                System.out.println("DatabaseTriggered Found new records : "+listNewRecords.size());
                for (Records newRecord : listNewRecords) {
                    newRecord.setNew(false);
                    service.save(newRecord);
                }
            }
        }, 0, TRIGGER_PERIOD, TimeUnit.SECONDS);
    }
}
