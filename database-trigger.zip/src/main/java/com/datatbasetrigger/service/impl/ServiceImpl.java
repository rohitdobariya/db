package com.datatbasetrigger.service.impl;

import com.datatbasetrigger.domain.Records;
import com.datatbasetrigger.repository.DatabaseTriggerRepository;
import com.datatbasetrigger.service.Service;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@org.springframework.stereotype.Service
public class ServiceImpl implements Service {

    @Autowired
    private DatabaseTriggerRepository repository;

    @Override
    public List<Records> findRecordByIsNew(boolean isNew) {
        return repository.findRecordByIsNew(isNew);
    }

    @Override
    public List<Records> findAll() {
        return repository.findAll();
    }

    @Override
    public Records save(Records records) {
        return repository.save(records);
    }
}
