package com.datatbasetrigger;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatabaseTriggerApp {

	public static void main(String[] args) {
		SpringApplication.run(DatabaseTriggerApp.class, args);
	}

}
