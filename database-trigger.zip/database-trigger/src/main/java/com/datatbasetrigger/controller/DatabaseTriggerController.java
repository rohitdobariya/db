package com.datatbasetrigger.controller;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.datatbasetrigger.domain.DatabaseTrigger;
import com.datatbasetrigger.repository.DatabaseTriggerRepository;
 

@RestController
@RequestMapping("/api")
public class DatabaseTriggerController {

	@Autowired
	DatabaseTriggerRepository databaseTriggerRepository;
 
	final String lexicon = "ABCDEFGHIJKLMNOPQRSTUVWXYZ12345674890";

	final java.util.Random rand = new java.util.Random();
	
	@GetMapping("/students")
	public ResponseEntity<List<DatabaseTrigger>> getAllStudents() {
		try {
			List<DatabaseTrigger> students = databaseTriggerRepository.findAll();
			return new ResponseEntity<>(students, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	@GetMapping("/student/add")
	public ResponseEntity<List<DatabaseTrigger>> insertStudents() {
		try {
			List<DatabaseTrigger> dbTriggerList = new ArrayList<>();
			for (int i = 0; i < 3; i++) {
				DatabaseTrigger dbTrigger = new DatabaseTrigger();
				dbTrigger.setName(randomIdentifier());
				dbTriggerList.add(dbTrigger);
			}
			for (DatabaseTrigger dbtrigger : dbTriggerList) {
				databaseTriggerRepository.save(dbtrigger);
			}
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		} catch (Exception e) {
			return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	public String randomIdentifier() {
	    StringBuilder builder = new StringBuilder();
	    while(builder.toString().length() == 0) {
	        int length = rand.nextInt(5)+5;
	        for(int i = 0; i < length; i++) {
	            builder.append(lexicon.charAt(rand.nextInt(lexicon.length())));
	        }
	    }
	    return builder.toString();
	}
}
