package com.datatbasetrigger;

import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.datatbasetrigger.domain.DatabaseTrigger;
import com.datatbasetrigger.repository.DatabaseTriggerRepository;

@SpringBootApplication
public class DatabaseTriggerApp implements ApplicationRunner {

	@Autowired
	DatabaseTriggerRepository repository;

	public static void main(String[] args) {
		SpringApplication.run(DatabaseTriggerApp.class, args);
	}

	@Override
	public void run(ApplicationArguments args) throws Exception {
		ScheduledExecutorService ses = Executors.newScheduledThreadPool(10);
		ses.scheduleAtFixedRate(new Runnable() {
			@Override
			public void run() {
				System.out.println("Calling new Students");
				List<DatabaseTrigger> listStudent = repository.findStudentByIsNew(true);
				for (DatabaseTrigger student : listStudent) {
					System.out.println("new record found -> Name :" + student.getName() + " with id :" + student.getId());
					student.setNew(false);
					repository.save(student);
				}
			}
		}, 0, 10, TimeUnit.SECONDS);
	}
}
