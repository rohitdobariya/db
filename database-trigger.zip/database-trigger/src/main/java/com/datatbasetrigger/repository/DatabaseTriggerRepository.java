package com.datatbasetrigger.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.datatbasetrigger.domain.DatabaseTrigger;

public interface DatabaseTriggerRepository extends JpaRepository<DatabaseTrigger, Long> {
	List<DatabaseTrigger> findStudentByIsNew(boolean isNew);
}
