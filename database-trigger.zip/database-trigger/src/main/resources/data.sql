INSERT INTO STUDENT (name) VALUES('Krutik Dhunt');
INSERT INTO STUDENT (name) VALUES('Rajesh Desai');
INSERT INTO STUDENT (name) VALUES('Krish Patel');